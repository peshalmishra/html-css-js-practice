/******************** Problem Statement 8 ********************/

/*
Tasks:
1. Predict the output of the code
2. Explain why it behaves that way
3. Highlight differences between function declaration and function expression
*/


/******************** ORIGINAL CODE ********************/
sayHello(); // ✅ Works because function declarations are hoisted

function sayHello() {
  console.log("Hello");
}

sayHi(); // ❌ Causes error because sayHi is a function expression

var sayHi = function () {
  console.log("Hi");
};


/******************** EXPLANATION ********************/

/*
1) sayHello():
- This is a function declaration.
- Function declarations are fully hoisted: both the name and the body.
- JS internally treats it as if it's at the top:
    function sayHello() { ... }
- So calling sayHello() before its definition works.
- Output: "Hello"

2) sayHi():
- This is a function expression assigned to a variable declared with 'var'.
- During hoisting, only the variable declaration is moved to the top:
    var sayHi; // initialized as undefined
- The function is assigned at runtime, after the call.
- So calling sayHi() before assignment tries to execute undefined as a function.
- Output: TypeError: sayHi is not a function

3) Key Differences:
- Function Declaration:
    * Fully hoisted
    * Can be called before definition
- Function Expression:
    * Only variable hoisted (undefined)
    * Cannot be called before assignment
*/


/******************** PREDICTED OUTPUT ********************/

/*
Hello
TypeError: sayHi is not a function
*/
