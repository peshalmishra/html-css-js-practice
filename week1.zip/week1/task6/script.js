/******************** Problem Statement 6 ********************/

/*
Tasks Covered:
1. Predict the output
2. Explain:
   - Why 'a' prints undefined
   - Why 'b' throws an error
   - Why 'c' is undefined inside the function
3. Identify the line that causes the error
4. Rewrite the code so no error occurs
5. Ensure all console.log statements print valid values
*/


/******************** PART 1: ORIGINAL CODE ********************/

// console.log(a)
// console.log(b)
// var a = 10
// let b = 20
// function test() {
//   console.log(c)
//   var c = 30
// }
// test()


/******************** PART 2: PREDICTED OUTPUT ********************/

/*
undefined
ReferenceError: Cannot access 'b' before initialization

Program stops due to error.
test() function never executes.
*/


/******************** PART 3: EXPLANATION ********************/

/*
1) Why 'a' prints undefined
- 'var' variables are hoisted to the top.
- Only declaration is hoisted, not initialization.
- So JavaScript treats it as:
    var a;
    console.log(a); // undefined
    a = 10;

2) Why 'b' throws an error
- 'let' variables are hoisted but placed in Temporal Dead Zone (TDZ).
- Accessing before initialization causes ReferenceError.

3) Why 'c' is undefined inside the function
- 'var c' is hoisted inside the function.
- It behaves like:
    var c;
    console.log(c); // undefined
    c = 30;
*/


/******************** PART 4: ERROR LINE ********************/

/*
The line causing the error:
console.log(b)
*/


/******************** PART 5: CORRECTED CODE (NO ERRORS) ********************/

var a = 10
let b = 20

console.log(a) // 10
console.log(b) // 20

function test() {
  var c = 30
  console.log(c) // 30
}

test()


/******************** FINAL OUTPUT ********************/

/*
10
20
30
*/
