const container = document.getElementById("container")

const ul = document.createElement("ul")
container.appendChild(ul)

const students = [
  { name: "Aman", marks: 85 },
  { name: "Riya", marks: 90 },
  { name: "Karan", marks: 78 }
]

students.forEach(student => {
  const li = document.createElement("li")
  li.textContent = `${student.name} – ${student.marks}`
  li.style.backgroundColor = "#" + Math.floor(Math.random()*16777215).toString(16)
  li.style.padding = "8px"
  li.style.margin = "5px 0"
  ul.appendChild(li)
})
